package com.awltk.armornum;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class ArmorNumClient implements ClientModInitializer {

    private static class_304 configKey;

    public static class_304 getConfigKey() {
        return configKey;
    }

    @Override
    public void onInitializeClient() {
        ModConfig.getInstance();

        configKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.armor_display_averatec.open_config",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_N,
                "category.armor_display_averatec"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (configKey.method_1436()) {
                client.method_1507(new ArmorDisplayScreen(client.field_1755));
            }
        });

        HudRenderCallback.EVENT.register(ArmorHudRenderer::render);
    }
}
