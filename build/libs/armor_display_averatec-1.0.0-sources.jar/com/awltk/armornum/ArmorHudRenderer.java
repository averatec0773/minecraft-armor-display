package com.awltk.armornum;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1304;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5134;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.minecraft.class_9779;

@Environment(EnvType.CLIENT)
public class ArmorHudRenderer {

    private static final int HEARTS_BASE_FROM_BOTTOM = 39;
    private static final int ROW_HEIGHT = 10;
    private static final int HP_PER_ROW = 20;
    private static final int MAX_HEART_ROWS = 8;

    public static void render(class_332 context, class_9779 tickCounter) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1690.field_1842) return;
        if (!ModConfig.getInstance().enabled) return;

        class_1657 player = client.field_1724;
        int armorValue = (int) Math.floor(calculateTotalArmor(player));
        if (armorValue <= 0) return;

        int scaledWidth = context.method_51421();
        int scaledHeight = context.method_51443();

        int x = scaledWidth / 2 - 91;
        int y = getTextY(player, scaledHeight);

        context.method_51433(client.field_1772, "Total Armor: " + armorValue, x, y, ModConfig.getInstance().textColor, true);
    }

    /**
     * Calculates total armor value.
     *
     * On RPG servers, weapon/shield armor bonuses may not be synced to the
     * vanilla client attribute system. This method supplements getAttributeValue
     * by reading ATTRIBUTE_MODIFIERS components from mainhand/offhand directly,
     * and only adds modifiers that aren't already tracked in the attribute instance.
     */
    private static double calculateTotalArmor(class_1657 player) {
        class_1324 instance = player.method_5996(class_5134.field_23724);
        double armor = (instance != null) ? instance.method_6194() : 0;

        if (instance != null) {
            armor += getUntracked(instance, player.method_6047(), class_1304.field_6173);
            armor += getUntracked(instance, player.method_6079(), class_1304.field_6171);
        }

        return armor;
    }

    /**
     * Returns armor bonus from an item's component that is NOT already reflected
     * in the vanilla attribute instance (avoids double-counting).
     */
    private static double getUntracked(class_1324 instance, class_1799 stack, class_1304 slot) {
        if (stack.method_7960()) return 0;
        class_9285 comp = stack.method_57824(class_9334.field_49636);
        if (comp == null) return 0;

        double bonus = 0;
        for (class_9285.class_9287 entry : comp.comp_2393()) {
            if (!entry.comp_2395().equals(class_5134.field_23724)) continue;
            // matches() handles ANY, HAND, MAINHAND, OFFHAND correctly
            if (!entry.comp_2397().method_57286(slot)) continue;
            class_1322 modifier = entry.comp_2396();
            // Only add if NOT already tracked in the vanilla attribute instance
            if (!instance.method_6196(modifier.comp_2447())) {
                bonus += modifier.comp_2449();
            }
        }
        return bonus;
    }

    private static int getTextY(class_1657 player, int scaledHeight) {
        int heartRows;
        if (player.method_31549().field_7477) {
            heartRows = 1;
        } else {
            float totalHealth = player.method_6063() + player.method_6067();
            heartRows = Math.min(MAX_HEART_ROWS,
                    Math.max(1, (int) Math.ceil(totalHealth / HP_PER_ROW)));
        }
        return scaledHeight - HEARTS_BASE_FROM_BOTTOM - heartRows * ROW_HEIGHT - ROW_HEIGHT;
    }
}
