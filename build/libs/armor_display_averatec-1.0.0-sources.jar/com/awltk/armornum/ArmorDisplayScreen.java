package com.awltk.armornum;

import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

public class ArmorDisplayScreen extends class_437 {

    private static final class_2561 AUTHOR = class_2561.method_43470("by averatec0773").method_27694(s -> s.method_36139(0xFFFF55));
    private final class_437 parent;

    private boolean rebinding = false;
    private class_4185 keybindButton;

    public ArmorDisplayScreen(class_437 parent) {
        super(class_2561.method_43470("Armor Display Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        ModConfig config = ModConfig.getInstance();
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        // Toggle display on/off
        this.method_37063(class_4185.method_46430(
                buildToggleText(config.enabled),
                btn -> {
                    config.enabled = !config.enabled;
                    config.save();
                    btn.method_25355(buildToggleText(config.enabled));
                })
                .method_46434(cx - 100, cy - 35, 200, 20)
                .method_46431());

        // Cycle text color preset
        this.method_37063(class_4185.method_46430(
                buildColorText(config.textColor),
                btn -> {
                    int next = (getColorIndex(config.textColor) + 1) % ModConfig.COLOR_PRESETS.length;
                    config.textColor = ModConfig.COLOR_PRESETS[next];
                    config.save();
                    btn.method_25355(buildColorText(config.textColor));
                })
                .method_46434(cx - 100, cy - 10, 200, 20)
                .method_46431());

        // Keybinding rebind button
        keybindButton = class_4185.method_46430(
                buildKeybindText(),
                btn -> {
                    rebinding = true;
                    btn.method_25355(class_2561.method_43470("> Press a key... <"));
                })
                .method_46434(cx - 100, cy + 15, 200, 20)
                .method_46431();
        this.method_37063(keybindButton);

        // Done
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Done"),
                btn -> this.field_22787.method_1507(this.parent))
                .method_46434(cx - 50, cy + 43, 100, 20)
                .method_46431());
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (rebinding) {
            rebinding = false;
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                class_304 key = ArmorNumClient.getConfigKey();
                key.method_1422(class_3675.class_307.field_1668.method_1447(keyCode));
                class_304.method_1426();
                this.field_22787.field_1690.method_1640();
            }
            keybindButton.method_25355(buildKeybindText());
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        context.method_27534(this.field_22793, this.field_22785, cx, cy - 65, 0xFFFFFF);
        context.method_27534(this.field_22793, AUTHOR, cx, cy - 53, 0xFFFFFF);
    }

    // --- helpers ---

    private static class_2561 buildToggleText(boolean enabled) {
        return class_2561.method_43470("Armor Display: ").method_10852(
                class_2561.method_43470(enabled ? "ON" : "OFF")
                        .method_27694(s -> s.method_36139(enabled ? 0x55FF55 : 0xFF5555))
        );
    }

    private static class_2561 buildColorText(int color) {
        String name = ModConfig.COLOR_NAMES[getColorIndex(color)];
        return class_2561.method_43470("Text Color: ").method_10852(
                class_2561.method_43470(name).method_27694(s -> s.method_36139(color))
        );
    }

    private static class_2561 buildKeybindText() {
        return class_2561.method_43470("Open Menu: ").method_10852(
                ArmorNumClient.getConfigKey().method_16007()
        );
    }

    private static int getColorIndex(int color) {
        for (int i = 0; i < ModConfig.COLOR_PRESETS.length; i++) {
            if (ModConfig.COLOR_PRESETS[i] == color) return i;
        }
        return 0;
    }
}
