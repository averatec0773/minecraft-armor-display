package com.awltk.armornum;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;

@Environment(EnvType.CLIENT)
public class ArmorHudRenderer {

    // Vanilla armor bar starts at scaledWidth/2 - 91, is 80px wide (10 icons x 8px)
    // Vanilla armor bar row is at approximately scaledHeight - 49
    private static final int ARMOR_BAR_X_OFFSET = -91;
    private static final int ARMOR_BAR_WIDTH = 80;
    private static final int ARMOR_BAR_Y_FROM_BOTTOM = 49;

    public static void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) return;

        PlayerEntity player = client.player;

        double armor = player.getAttributeValue(EntityAttributes.ARMOR);
        int armorValue = (int) Math.floor(armor);
        if (armorValue <= 0) return;

        int scaledWidth = context.getScaledWindowWidth();
        int scaledHeight = context.getScaledWindowHeight();

        // Position text just to the right of the vanilla armor bar
        int x = scaledWidth / 2 + ARMOR_BAR_X_OFFSET + ARMOR_BAR_WIDTH + 2;
        int y = scaledHeight - ARMOR_BAR_Y_FROM_BOTTOM;

        String text = String.valueOf(armorValue);
        context.drawText(client.textRenderer, text, x, y, 0xFFFFFF, true);
    }
}
